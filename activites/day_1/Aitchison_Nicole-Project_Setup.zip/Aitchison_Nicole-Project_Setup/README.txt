Nicole Aicthison's WSP Portal Page:
http://nlaitchison.github.com/WSP/index.html

Fat Wreck Chords Website Redesign: 
http://nlaitchison.github.com/WSP/project/index.html